msg\_parser.properties package
==============================

Submodules
----------

msg\_parser.properties.ms\_props\_date\_type\_map module
--------------------------------------------------------

.. automodule:: msg_parser.properties.ms_props_date_type_map
    :members:
    :undoc-members:
    :show-inheritance:

msg\_parser.properties.ms\_props\_generator module
--------------------------------------------------

.. automodule:: msg_parser.properties.ms_props_generator
    :members:
    :undoc-members:
    :show-inheritance:

msg\_parser.properties.ms\_props\_id\_map module
------------------------------------------------

.. automodule:: msg_parser.properties.ms_props_id_map
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: msg_parser.properties
    :members:
    :undoc-members:
    :show-inheritance:
