msg\_parser package
===================

Subpackages
-----------

.. toctree::

    msg_parser.properties

Submodules
----------

msg\_parser.cli module
----------------------

.. automodule:: msg_parser.cli
    :members:
    :undoc-members:
    :show-inheritance:

msg\_parser.data\_models module
-------------------------------

.. automodule:: msg_parser.data_models
    :members:
    :undoc-members:
    :show-inheritance:

msg\_parser.email\_builder module
---------------------------------

.. automodule:: msg_parser.email_builder
    :members:
    :undoc-members:
    :show-inheritance:

msg\_parser.msg\_parser module
------------------------------

.. automodule:: msg_parser.msg_parser
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: msg_parser
    :members:
    :undoc-members:
    :show-inheritance:
