=======
History
=======

0.1.0 (2018-10-26)
------------------

* Initial commit.


1.0.0 (2018-10-29)
------------------
* Initial pypi release.
* Added headers_dict to message object.
