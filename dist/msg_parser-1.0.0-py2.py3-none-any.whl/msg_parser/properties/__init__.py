# -*- coding: utf-8 -*-

from ms_props_date_type_map import DATA_TYPE_MAP
from ms_props_id_map import PROPS_ID_MAP
