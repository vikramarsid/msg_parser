=======
History
=======

0.1.0 (2018-10-26)
------------------

* First release on PyPI.
